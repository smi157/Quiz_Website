-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ap_chemistry
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `question_id` int NOT NULL AUTO_INCREMENT,
  `question_text` text NOT NULL,
  `difficulty_id` int NOT NULL,
  `source_id` int DEFAULT NULL,
  PRIMARY KEY (`question_id`),
  KEY `difficulty_id` (`difficulty_id`),
  KEY `source_id` (`source_id`),
  CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`difficulty_id`) REFERENCES `difficulty_levels` (`difficulty_id`),
  CONSTRAINT `questions_ibfk_2` FOREIGN KEY (`source_id`) REFERENCES `sources` (`source_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (2,'A solution is prepared by adding 16 g of CH3OH (molar mass 32 g) to 90. g of H2O (molar mass 18 g). The mole\nfraction of CH3OH in this solution is closest to which of the following?',1,1),(3,'Equal masses of He and Ne are placed in a sealed container. What is the partial pressure of He if the total pressure\nin the container is 6 atm?',2,1),(4,'How many carbon atoms are contained in 2.8 g of C2H4 ?',1,1),(5,'A compound contains 1.10 mol of K, 0.55 mol of Te, and 1.65 mol of O. What is the simplest formula of this\ncompound?',1,1),(6,'A compound contains 30. percent sulfur and 70. percent fluorine by mass. The empirical formula of the compound is:',1,1),(7,'After completing an experiment to determine gravimetrically the percentage of water in a hydrate, a student\nreported a value of 38 percent. The correct value for the percentage of water in the hydrate is 51 percent. Which of\nthe following is the most likely explanation for this difference?',2,1),(8,'In which of the following compounds is the mass ratio of chromium to oxygen closest to 1.62 to 1.00?',1,1),(9,'When hafnium metal is heated in an atmosphere of chlorine gas, the product of the reaction is found to contain 62.2\npercent Hf by mass and 37.4 percent Cl by mass. What is the empirical formula for this compound?',1,1),(10,'What number of moles of O2 is needed to produce 14.2 grams of P4O10 from P? (Molecular weight P4O10 = 284)',2,1);
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-07 18:46:04
