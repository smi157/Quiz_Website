-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ap_chemistry
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `options` (
  `option_id` int NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `option_letter` char(1) NOT NULL,
  `option_text` text NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `question_id` (`question_id`,`option_letter`),
  CONSTRAINT `options_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `questions` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES (5,2,'A','0.1',1),(6,2,'B','0.2',0),(7,2,'C','0.3',0),(8,2,'D','0.4',0),(9,3,'A','1 atm',0),(10,3,'B','2 atm',0),(11,3,'C','3 atm',0),(12,3,'D','5 atm',1),(13,4,'A','1.2x10^23',1),(14,4,'B','3.0x10^23',0),(15,4,'C','6.0x10^23',0),(16,4,'D','1.2x10^24',0),(17,5,'A','KTeO',0),(18,5,'B','KTe2O',0),(19,5,'C','K2TeO3',1),(20,5,'D','K2TeO6',0),(21,6,'A','SF',0),(22,6,'B','SF2',0),(23,6,'C','SF4',1),(24,6,'D','SF6',0),(25,7,'A','Strong initial heating caused some of the hydrate sample to spatter out of the crucible.',0),(26,7,'B','The dehydrated sample absorbed moisture after heating.',1),(27,7,'C','The crucible was not heated to constant mass before use.',0),(28,7,'D','Excess heating caused the dehydrated sample to decompose.',0),(29,8,'A','CrO3',0),(30,8,'B','CrO2',1),(31,8,'C','Cr2O',0),(32,8,'D','Cr2O3',0),(33,9,'A','HfCl2',0),(34,9,'B','HfCl3',1),(35,9,'C','HfCl4',0),(36,9,'D','Hf2Cl3',0),(37,10,'A','0.0500 mole',0),(38,10,'B','0.125 mole',0),(39,10,'C','0.250 mole',1),(40,10,'D','0.500 mole',0);
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-07 18:46:04
