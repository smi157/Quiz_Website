-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ap_chemistry
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subtopics`
--

DROP TABLE IF EXISTS `subtopics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subtopics` (
  `subtopic_id` int NOT NULL AUTO_INCREMENT,
  `unit_id` int NOT NULL,
  `subtopic_code` varchar(10) NOT NULL,
  `subtopic_name` varchar(255) NOT NULL,
  PRIMARY KEY (`subtopic_id`),
  UNIQUE KEY `subtopic_code` (`subtopic_code`),
  KEY `unit_id` (`unit_id`),
  CONSTRAINT `subtopics_ibfk_1` FOREIGN KEY (`unit_id`) REFERENCES `units` (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtopics`
--

LOCK TABLES `subtopics` WRITE;
/*!40000 ALTER TABLE `subtopics` DISABLE KEYS */;
INSERT INTO `subtopics` VALUES (1,1,'1.1','Moles and Molar Mass'),(2,1,'1.2','Mass Spectroscopy of Elements'),(3,1,'1.3','Elemental Composition of Pure Substances'),(4,1,'1.4','Composition of Mixtures'),(5,1,'1.5','Atomic Structure and Electron Configuration'),(6,1,'1.6','Photoelectron Spectroscopy'),(7,1,'1.7','Periodic Trends'),(8,1,'1.8','Valence Electrons and Ionic Compounds'),(9,2,'2.1','Types of Chemical Bonds'),(10,2,'2.2','Intramolecular Force and Potential Energy'),(11,2,'2.3','Structure of Ionic Solids'),(12,2,'2.4','Structure of Metals and Alloys'),(13,2,'2.5','Lewis Diagrams'),(14,2,'2.6','Resonance and Formal Charge'),(15,2,'2.7','VSEPR and Bond Hybridization'),(16,3,'3.1','Intermolecular Forces'),(17,3,'3.2','Properties of Solids'),(18,3,'3.3','Solids, Liquids, and Gases'),(19,3,'3.4','Ideal Gas Law'),(20,3,'3.5','Kinetic Molecular Theory'),(21,3,'3.6','Deviation from Ideal Gas Law'),(22,3,'3.7','Solutions and Mixtures'),(23,3,'3.8','Representations of Solutions'),(24,3,'3.9','Separation of Solutions'),(25,3,'3.10','Solubility'),(26,3,'3.11','Spectroscopy and the Electromagnetic Spectrum'),(27,3,'3.12','Photoelectric Effect'),(28,3,'3.13','Beer-Lambert Law'),(29,4,'4.1','Introduction to Chemical Reactions'),(30,4,'4.2','Net Ionic Equations'),(31,4,'4.3','Representations of Reactions'),(32,4,'4.4','Physical and Chemical Changes'),(33,4,'4.5','Stoichiometry'),(34,4,'4.6','Introduction to Titration'),(35,4,'4.7','Types of Chemical Reactions'),(36,4,'4.8','Introduction to Acid-Base Reactions'),(37,4,'4.9','Oxidation-Reduction (Redox) Reactions'),(38,5,'5.1','Reaction Rates'),(39,5,'5.2','Rate Law and Order'),(40,5,'5.3','Concentration Changes Over Time'),(41,5,'5.4','Elementary Reactions'),(42,5,'5.5','Collision Model'),(43,5,'5.6','Reaction Energy Profile'),(44,5,'5.7','Introduction to Reaction Mechanisms'),(45,5,'5.8','Reaction Mechanism and Rate Law'),(46,5,'5.9','Steady-State Approximation'),(47,5,'5.10','Multistep Reaction Energy Profile'),(48,5,'5.11','Catalysis'),(49,6,'6.1','Endothermic and Exothermic Processes'),(50,6,'6.2','Energy Diagrams'),(51,6,'6.3','Heat Transfer and Thermal Equilibrium'),(52,6,'6.4','Heat Capacity and Calorimetry'),(53,6,'6.5','Energy of Phase Changes'),(54,6,'6.6','Introduction to Enthalpy of Reaction'),(55,6,'6.7','Bond Enthalpies'),(56,6,'6.8','Enthalpy of Formation'),(57,6,'6.9','Hess\'s Law'),(58,7,'7.1','Introduction to Equilibrium'),(59,7,'7.2','Direction of Reversible Reactions'),(60,7,'7.3','Reaction Quotient and Equilibrium Constant'),(61,7,'7.4','Calculating the Equilibrium Constant'),(62,7,'7.5','Magnitude of the Equilibrium Constant'),(63,7,'7.6','Properties of the Equilibrium Constant'),(64,7,'7.7','Calculating Equilibrium Concentrations'),(65,7,'7.8','Representations of Equilibrium'),(66,7,'7.9','Introduction to Le Châtelier\'s Principle'),(67,7,'7.10','Reaction Quotient and Le Châtelier\'s Principle'),(68,7,'7.11','Introduction to Solubility Equilibria'),(69,7,'7.12','Common-Ion Effect'),(70,8,'8.1','Introduction to Acids and Bases'),(71,8,'8.2','pH and pOH of Strong Acids and Bases'),(72,8,'8.3','Weak Acid and Base Equilibria'),(73,8,'8.4','Acid-Base Reactions and Buffers'),(74,8,'8.5','Acid-Base Titrations'),(75,8,'8.6','Molecular Structure of Acids and Bases'),(76,8,'8.7','pH and pKa'),(77,8,'8.8','Properties of Buffers'),(78,8,'8.9','Henderson-Hasselbalch Equation'),(79,8,'8.10','Buffer Capacity'),(80,8,'8.11','Titration Curves'),(81,9,'9.1','Introduction to Entropy'),(82,9,'9.2','Absolute Entropy and Entropy Change'),(83,9,'9.3','Gibbs Free Energy and Thermodynamic Favorability'),(84,9,'9.4','Thermodynamic and Kinetic Control'),(85,9,'9.5','Free Energy and Equilibrium'),(86,9,'9.6','Coupled Reactions'),(87,9,'9.7','Galvanic (Voltaic) and Electrolytic Cells'),(88,9,'9.8','Cell Potential and Free Energy'),(89,9,'9.9','Cell Potential Under Nonstandard Conditions'),(90,9,'9.10','Electrolysis and Faraday\'s Law'),(91,9,'9.11','Thermodynamics of Electrochemistry');
/*!40000 ALTER TABLE `subtopics` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-07 18:46:04
