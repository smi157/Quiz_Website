-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ap_chemistry
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping routines for database 'ap_chemistry'
--
/*!50003 DROP PROCEDURE IF EXISTS `GetRandomQuestions` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GetRandomQuestions`(
    IN difficulty_levels VARCHAR(255),
    IN source_names VARCHAR(255),
    IN subtopic_codes VARCHAR(255),
    IN num_questions INT
)
BEGIN
    -- Select random questions with all options as separate columns
    SELECT 
        q.question_id AS id,
        q.question_text,
        MAX(CASE WHEN o.option_letter = 'A' THEN o.option_text END) AS option_a,
        MAX(CASE WHEN o.option_letter = 'B' THEN o.option_text END) AS option_b,
        MAX(CASE WHEN o.option_letter = 'C' THEN o.option_text END) AS option_c,
        MAX(CASE WHEN o.option_letter = 'D' THEN o.option_text END) AS option_d,
        MAX(CASE WHEN o.is_correct = 1 THEN o.option_letter END) AS correct_answer,
        d.difficulty_id AS difficulty,
        s.source_name AS source,
        GROUP_CONCAT(DISTINCT st.subtopic_code ORDER BY st.subtopic_code SEPARATOR ', ') AS topic
    FROM questions q
    JOIN difficulty_levels d ON q.difficulty_id = d.difficulty_id
    JOIN sources s ON q.source_id = s.source_id
    JOIN question_subtopics qs ON q.question_id = qs.question_id
    JOIN subtopics st ON qs.subtopic_id = st.subtopic_id
    JOIN options o ON q.question_id = o.question_id
    WHERE 
        -- Filter by difficulty (comma-separated IDs like '1,2,3')
        (difficulty_levels IS NULL OR difficulty_levels = '' OR FIND_IN_SET(d.difficulty_id, difficulty_levels) > 0)
        -- Filter by source name
        AND (source_names IS NULL OR source_names = '' OR FIND_IN_SET(s.source_name, source_names) > 0)
        -- Filter by subtopic code (like '1.1,1.3')
        AND (subtopic_codes IS NULL OR subtopic_codes = '' OR 
             EXISTS (
                 SELECT 1 FROM question_subtopics qs2
                 JOIN subtopics st2 ON qs2.subtopic_id = st2.subtopic_id
                 WHERE qs2.question_id = q.question_id
                 AND FIND_IN_SET(st2.subtopic_code, subtopic_codes) > 0
             ))
    GROUP BY 
        q.question_id, q.question_text, d.difficulty_id, s.source_name
    ORDER BY RAND()
    LIMIT num_questions;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-07 18:46:04
